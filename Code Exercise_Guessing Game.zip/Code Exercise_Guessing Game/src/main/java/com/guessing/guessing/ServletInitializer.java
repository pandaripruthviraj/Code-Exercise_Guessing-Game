/**
 * Copyright (c) 2020 Pruthviraj Pudari to Present.
 * All rights reserved.
 */
package com.guessing.guessing;

import org.springframework.boot.builder.SpringApplicationBuilder;
import org.springframework.boot.web.servlet.support.SpringBootServletInitializer;

public class ServletInitializer extends SpringBootServletInitializer {

	@Override
	protected SpringApplicationBuilder configure(SpringApplicationBuilder application) {
		return application.sources(GuessingApplication.class);
	}

}
