/**
 * Copyright (c) 2020 Pruthviraj Pudari to Present.
 * All rights reserved.
 */
package com.guessing.guessing;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.ComponentScan;

@SpringBootApplication
@ComponentScan({ "com.guessing.*" })
public class GuessingApplication {

	public static void main(String[] args) {
		SpringApplication.run(GuessingApplication.class, args);
	}

}
