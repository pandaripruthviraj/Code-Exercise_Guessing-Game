/**
 * Copyright (c) 2020 Pruthviraj Pudari to Present.
 * All rights reserved.
 */

package com.guessing.game;

import java.util.Random;

import org.json.JSONException;
import org.json.JSONObject;
import org.springframework.stereotype.Service;

/**
 * Service Implementation of game service interface.
 *
 * @author Pruthviraj Pudari
 *
 */
@Service
public class GameServiceImpl implements GameService {

	private Random random = new Random();

	/**
	 * Implementation of validating the user guess.
	 *
	 * @param userGuess
	 * @param numberOfTries
	 * @return resultJson
	 */
	public String play(int guess, int numberOfTries) throws JSONException {
		String result = "";
		JSONObject resultJson = new JSONObject();
		if (!(guess >= 1 && guess <= 10)) {
			resultJson.put("retry", false);
			resultJson.put("data", "Internal server error.");
			result = resultJson.toString();
		}
		int numberToGuess = nextInt(1, 10 + 1);
		String numberOfTriesInWords = getNumberOfTriesInWords(numberOfTries);
		if (guess == numberToGuess) {
			resultJson.put("retry", true);
			resultJson.put("data", "Right! You have won the game.");
			result = resultJson.toString();
		} else if (numberOfTriesInWords != "NaN") {
			if ((numberToGuess - guess) >= 3 || (guess - numberToGuess) >= 3) {
				resultJson.put("retry", false);
				resultJson.put("data", "Your " + numberOfTriesInWords + " guess is:" + guess + " (cold)");
				result = resultJson.toString();
			} else if ((numberToGuess - guess) == 2 || (guess - numberToGuess) == 2) {
				resultJson.put("retry", false);
				resultJson.put("data", "Your " + numberOfTriesInWords + " guess is:" + guess + " (warm)");
				result = resultJson.toString();
			} else if ((numberToGuess - guess) == 1 || (guess - numberToGuess) == 1) {
				resultJson.put("retry", false);
				resultJson.put("data", "Your " + numberOfTriesInWords + " guess is:" + guess + " (hot)");
				result = resultJson.toString();
			}
		}
		return result;
	}

	/**
	 * @param numberOfTries
	 * @return numberOfTriesInWords
	 */
	private String getNumberOfTriesInWords(int numberOfTries) {
		String numberOfTriesInWords = "NaN";
		if (numberOfTries == 1 || numberOfTries <= 3) {
			if (numberOfTries == 1) {
				numberOfTriesInWords = "first";
			} else if (numberOfTries == 2) {
				numberOfTriesInWords = "second";
			} else if (numberOfTries == 3) {
				numberOfTriesInWords = "last";
			}
		}
		return numberOfTriesInWords;
	}

	/**
	 * @param lowerLimit
	 * @param upperLimit
	 * @return randomNumber
	 */
	private int nextInt(int lowerLimit, int upperLimit) {
		return lowerLimit + random.nextInt(upperLimit - lowerLimit);
	}
}
