/**
 * Copyright (c) 2020 Pruthviraj Pudari to Present.
 * All rights reserved.
 */
package com.guessing.game;

import org.json.JSONException;

/**
 * Game service having unimplemented methods.
 *
 * @author Pruthviraj Pudari
 *
 */
public interface GameService {

	/**
	 * An abstract method to validate the user guess.
	 *
	 * @param userGuess
	 * @param numberOfTries
	 *
	 */
	public String play(int userGuess, int numberOfTries) throws JSONException;

}
