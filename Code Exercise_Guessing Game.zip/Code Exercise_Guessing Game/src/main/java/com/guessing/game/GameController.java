/**
 * Copyright (c) 2020 Pruthviraj Pudari to Present.
 * All rights reserved.
 */
package com.guessing.game;

import java.util.Random;
import org.json.JSONException;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

/**
 * Guessing Game Controller
 *
 * @author Pruthviraj Pudari
 *
 */
@RestController
public class GameController {

	@Autowired
	GameService gameService;

	/**
	 * To check the server status.
	 *
	 * @return String
	 */
	@RequestMapping(value = "/game", method = RequestMethod.GET)
	public String welcome() {
		return "Welcome to Game Guesing";
	}

	/**
	 * Compares the user guess number with program generated number by calling
	 * service method.
	 *
	 * @param userGuess
	 * @param numberOfTries
	 * @return result.
	 */
	@RequestMapping(value = "/guessTheNumber", method = RequestMethod.GET)
	public String oi(@RequestParam("userGuess") int userGuess, @RequestParam("numberOfTries") int numberOfTries) {
		String result = "";
		if (numberOfTries <= 3) {
			try {
				result = gameService.play(userGuess, numberOfTries);
			} catch (JSONException e) {
				result = "{\"data\":\"Internal server error\",\"retry\":false}";
			}
		}
		return result;
	}
}
